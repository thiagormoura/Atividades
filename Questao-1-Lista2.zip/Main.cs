using System;

public class Program {

  public static void Main(string[] args) {
    Console.WriteLine("Digite seu nome");
   
    string s = Console.ReadLine();
    Console.WriteLine("seja bem vindo," + s );  
  }}